package com.example.hw09android;

public class EventDetails {
    String ID;
    String Name;
    String Artists;
    String Venue;
    String Date;
    String Category;
    String PriceRange;
    String TicketStatus;
    String BuyTicketAt;
    String SeatMap;
}
