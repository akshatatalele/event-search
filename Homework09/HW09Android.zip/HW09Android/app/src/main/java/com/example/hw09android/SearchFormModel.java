package com.example.hw09android;

public class SearchFormModel {
    String keyword;
    String category;
    String distance;
    String units;
    String radioValue;
    String locVal;
}
