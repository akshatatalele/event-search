package com.example.hw09android;

public class EventTable {
    String ID;
    String Date;
    String Name;
    String Category;
    String Venue;
    boolean isFavorite;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public String getVenue() {
        return Venue;
    }

    public void setVenue(String venue) {
        Venue = venue;
    }

    public boolean getIsFavorite() {
        return isFavorite;
    }

    public void setIsFavorite(boolean isFavorite) {
        this.isFavorite = isFavorite;
    }

    @Override
    public String toString() {
        return "EventTable{" +
                "ID='" + ID + '\'' +
                ", Date='" + Date + '\'' +
                ", Name='" + Name + '\'' +
                ", Category='" + Category + '\'' +
                ", Venue='" + Venue + '\'' +
                ", isFavorite=" + isFavorite +
                '}';
    }
}
