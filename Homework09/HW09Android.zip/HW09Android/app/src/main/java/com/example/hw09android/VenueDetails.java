package com.example.hw09android;

public class VenueDetails {
    String Address;
    String City;
    String PhoneNumber;
    String OpenHours;
    String GeneralRule;
    String ChildRule;
    int Latitude;
    int Longitude;
}
