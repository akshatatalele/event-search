package com.example.hw09android;

public class ArtistDetails {
    String Name;
    int Followers;
    int Popularity;
    String CheckAt;
    boolean ifDetailsPresent;
}
